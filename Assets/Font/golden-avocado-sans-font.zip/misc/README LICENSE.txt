Hello there!!!
Thank you for downloading GOLDEN AVOCADO font and taking time reading this note.

It is NOT FULL VERSION.

NOTE: This font is for PERSONAL USE ONLY. 

If you want to use for commercial purpose and full version, you can purchase here:
https://airotypestudio.com/product/golden-avocado/

Use Coupon Code "dafont30" for 30% off (LIMITED)

Visit our store at:
https://airotypestudio.com

or message us ainrofi@gmail.com if you have any question.

Thank you so much...

Have fun and good luck!!!